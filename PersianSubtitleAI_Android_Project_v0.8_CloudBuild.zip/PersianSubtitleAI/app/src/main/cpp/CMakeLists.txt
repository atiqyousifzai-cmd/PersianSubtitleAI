cmake_minimum_required(VERSION 3.22.1)
project(persian_whisper)

# Place the official whisper.cpp source checkout in app/src/main/cpp/whisper.
set(WHISPER_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
add_subdirectory(whisper)

add_library(persian_whisper SHARED whisper_jni.cpp)
target_include_directories(persian_whisper PRIVATE whisper/include whisper/ggml/include)
target_link_libraries(persian_whisper PRIVATE whisper android log)
