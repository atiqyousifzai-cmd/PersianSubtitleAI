#include <jni.h>
#include <string>
#include <vector>
#include "whisper.h"

static whisper_context * ctx(jlong p) { return reinterpret_cast<whisper_context *>(p); }

extern "C" JNIEXPORT jlong JNICALL
Java_com_persiansubtitleai_WhisperEngine_nativeInit(JNIEnv *env, jobject, jstring path) {
    const char *p = env->GetStringUTFChars(path, nullptr);
    whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    whisper_context *context = whisper_init_from_file_with_params(p, cp);
    env->ReleaseStringUTFChars(path, p);
    return reinterpret_cast<jlong>(context);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_persiansubtitleai_WhisperEngine_nativeTranscribe(JNIEnv *env, jobject, jlong ptr, jfloatArray input, jint threads) {
    auto *context = ctx(ptr);
    if (!context) return -1;
    const jsize n = env->GetArrayLength(input);
    if (n <= 0) return -2;
    jfloat *data = env->GetFloatArrayElements(input, nullptr);
    whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    params.n_threads = threads;
    params.language = "en";
    params.translate = false;
    params.no_context = true;
    params.single_segment = false;
    params.print_progress = false;
    params.print_realtime = false;
    params.print_timestamps = false;
    const int result = whisper_full(context, params, data, n);
    env->ReleaseFloatArrayElements(input, data, JNI_ABORT);
    return result;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_persiansubtitleai_WhisperEngine_nativeSegmentCount(JNIEnv *, jobject, jlong ptr) {
    return ptr ? whisper_full_n_segments(ctx(ptr)) : 0;
}
extern "C" JNIEXPORT jlong JNICALL
Java_com_persiansubtitleai_WhisperEngine_nativeSegmentStartMs(JNIEnv *, jobject, jlong ptr, jint i) {
    return ptr ? whisper_full_get_segment_t0(ctx(ptr), i) * 10LL : 0LL;
}
extern "C" JNIEXPORT jlong JNICALL
Java_com_persiansubtitleai_WhisperEngine_nativeSegmentEndMs(JNIEnv *, jobject, jlong ptr, jint i) {
    return ptr ? whisper_full_get_segment_t1(ctx(ptr), i) * 10LL : 0LL;
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_persiansubtitleai_WhisperEngine_nativeSegmentText(JNIEnv *env, jobject, jlong ptr, jint i) {
    const char *s = ptr ? whisper_full_get_segment_text(ctx(ptr), i) : "";
    return env->NewStringUTF(s ? s : "");
}
extern "C" JNIEXPORT void JNICALL
Java_com_persiansubtitleai_WhisperEngine_nativeFree(JNIEnv *, jobject, jlong ptr) {
    if (ptr) whisper_free(ctx(ptr));
}
