package com.persiansubtitleai

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.util.UnstableApi
import java.io.File
import java.util.concurrent.Executors

@UnstableApi
class MainActivity : Activity() {
    private lateinit var fileInfo: TextView
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private var selectedVideo: Uri? = null
    private val worker = Executors.newSingleThreadExecutor()

    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        selectedVideo = uri
        if (uri == null) {
            fileInfo.text = "هیچ ویدیویی انتخاب نشد."
            startButton.isEnabled = false
        } else {
            fileInfo.text = "ویدیو انتخاب شد: ${queryName(uri)}\nمدت: ${durationText(uri)}"
            startButton.isEnabled = true
            status.text = "برای شروع، دکمهٔ زیر را بزن."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.TOP
            setBackgroundColor(0xFF111019.toInt())
        }
        fun label(text: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        }
        root.addView(label("Persian Subtitle AI", 25f), match(-1, dp(54)))
        root.addView(label("زیرنویس خودکار انگلیسی به فارسی", 18f, 0xFFE7E1F5.toInt()), match(-1, dp(54)))
        val pick = Button(this).apply {
            text = "📁 انتخاب ویدیو از گالری"
            setOnClickListener { pickVideo.launch("video/*") }
        }
        root.addView(pick, match(-1, dp(58)))
        fileInfo = label("هنوز ویدیویی انتخاب نشده است.", 15f).apply { setPadding(dp(8), dp(14), dp(8), dp(14)) }
        root.addView(fileInfo, match(-1, dp(100)))
        root.addView(label("زبان خروجی: فارسی", 17f), match(-1, dp(42)))
        root.addView(label("زیرنویس سفید با حاشیه سیاه", 14f, 0xFFE7E1F5.toInt()), match(-1, dp(38)))
        startButton = Button(this).apply {
            text = "شروع ساخت زیرنویس و ویدیو"
            isEnabled = false
            setOnClickListener { beginProcessing() }
        }
        root.addView(startButton, match(-1, dp(60)))
        status = label("مدل Whisper را در پوشهٔ مدل برنامه قرار بده.", 13f, 0xFFBDB8C8.toInt())
        root.addView(status, match(-1, dp(100)))
        setContentView(root)
    }

    private fun beginProcessing() {
        val video = selectedVideo ?: return
        val model = File(filesDir, "models/ggml-tiny.en.bin")
        if (!model.exists()) {
            status.text = "فایل مدل پیدا نشد. مسیر لازم: Android/data/com.persiansubtitleai/files/models/ggml-tiny.en.bin"
            Toast.makeText(this, "ابتدا مدل Whisper tiny.en را در پوشهٔ گفته‌شده قرار بده.", Toast.LENGTH_LONG).show()
            return
        }
        startButton.isEnabled = false
        status.text = "مرحله ۱ از ۳: تشخیص گفتار و ترجمهٔ فارسی... گوشی را روشن نگه دار."
        worker.execute {
            try {
                val workDir = File(cacheDir, "subtitle_work").apply { mkdirs() }
                val pipeline = SubtitlePipeline(this)
                val segments = pipeline.createPersianSubtitles(video, model, workDir)
                if (segments.isEmpty()) error("گفتار انگلیسی قابل تشخیصی پیدا نشد")
                runOnUiThread { status.text = "مرحله ۲ از ۳: چسباندن زیرنویس روی تصویر..." }
                val output = File(getExternalFilesDir(null) ?: cacheDir, "Persian_Subtitles_${System.currentTimeMillis()}.mp4")
                SubtitleVideoExporter(this).export(video, output, segments) { result ->
                    result.onSuccess { mp4 ->
                        worker.execute {
                            try {
                                val saved = GallerySaver.saveMp4(this, mp4, "Persian_Subtitles_${System.currentTimeMillis()}")
                                runOnUiThread {
                                    status.text = "تمام شد! ویدیو در گالری، پوشه Movies/PersianSubtitleAI ذخیره شد."
                                    Toast.makeText(this, "ویدیوی فارسی ذخیره شد", Toast.LENGTH_LONG).show()
                                    startButton.isEnabled = true
                                }
                            } catch (e: Exception) { showFailure(e) }
                        }
                    }.onFailure { showFailure(it) }
                }
            } catch (e: Exception) { showFailure(e) }
        }
    }

    private fun showFailure(error: Throwable) = runOnUiThread {
        status.text = "خطا: ${error.localizedMessage ?: error.javaClass.simpleName}"
        startButton.isEnabled = true
        Toast.makeText(this, status.text, Toast.LENGTH_LONG).show()
    }

    private fun queryName(uri: Uri): String = contentResolver.query(uri, null, null, null, null)?.use {
        val i = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && it.moveToFirst()) it.getString(i) else "ویدیوی انتخاب‌شده"
    } ?: "ویدیوی انتخاب‌شده"

    private fun durationText(uri: Uri): String = try {
        val r = android.media.MediaMetadataRetriever()
        r.setDataSource(this, uri)
        val ms = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        r.release()
        "${ms / 60000} دقیقه و ${(ms / 1000) % 60} ثانیه"
    } catch (_: Exception) { "نامشخص" }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun match(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    override fun onDestroy() { worker.shutdown(); super.onDestroy() }
}
