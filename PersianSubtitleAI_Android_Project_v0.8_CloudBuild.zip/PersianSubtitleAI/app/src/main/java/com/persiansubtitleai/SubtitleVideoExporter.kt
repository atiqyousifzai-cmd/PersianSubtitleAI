package com.persiansubtitleai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.CanvasOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

/** Burns time-aligned Persian captions into the video frames using Media3 Transformer. */
@UnstableApi
class SubtitleVideoExporter(private val context: Context) {
    fun export(input: Uri, output: File, subtitles: List<SubtitleSegment>,
               onComplete: (Result<File>) -> Unit) {
        require(subtitles.isNotEmpty()) { "زیرنویسی برای چسباندن وجود ندارد" }
        output.parentFile?.mkdirs()
        val overlay = TimedPersianOverlay(subtitles)
        val effects = Effects(emptyList(), listOf(OverlayEffect(listOf(overlay))))
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(input)).setEffects(effects).build()
        val transformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition,
                                         exportResult: ExportResult) {
                    onComplete(if (output.exists() && output.length() > 0) Result.success(output)
                               else Result.failure(IllegalStateException("خروجی ساخته نشد")))
                }
                override fun onError(composition: androidx.media3.transformer.Composition,
                                     exportResult: ExportResult,
                                     exportException: ExportException) {
                    onComplete(Result.failure(exportException))
                }
            }).build()
        transformer.start(edited, output.absolutePath)
    }

    private class TimedPersianOverlay(private val segments: List<SubtitleSegment>) : CanvasOverlay(true) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.BLACK
            textAlign = Paint.Align.CENTER
            style = Paint.Style.STROKE
            strokeJoin = Paint.Join.ROUND
            strokeWidth = 5f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        private val bounds = Rect()

        override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
            val timeMs = presentationTimeUs / 1000L
            val text = segments.firstOrNull { timeMs >= it.startMs && timeMs <= it.endMs }?.text ?: return
            val width = canvas.width.toFloat()
            val maxWidth = width * 0.88f
            val lines = wrap(text, maxWidth, fill)
            val lineHeight = fill.textSize * 1.25f
            val startY = canvas.height * 0.88f - (lines.size - 1) * lineHeight
            lines.forEachIndexed { index, line ->
                val y = startY + index * lineHeight
                canvas.drawText(line, width / 2f, y, stroke)
                canvas.drawText(line, width / 2f, y, fill)
            }
        }

        override fun configure(videoSize: androidx.media3.common.util.Size) {
            super.configure(videoSize)
            fill.textSize = (videoSize.height * 0.045f).coerceIn(28f, 64f)
            stroke.textSize = fill.textSize
        }

        private fun wrap(text: String, maxWidth: Float, paint: Paint): List<String> {
            val result = mutableListOf<String>()
            var line = ""
            text.split(Regex("\\s+")).forEach { word ->
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (line.isNotEmpty() && paint.measureText(candidate) > maxWidth) {
                    result += line
                    line = word
                } else line = candidate
            }
            if (line.isNotEmpty()) result += line
            return result.take(2)
        }
    }
}
