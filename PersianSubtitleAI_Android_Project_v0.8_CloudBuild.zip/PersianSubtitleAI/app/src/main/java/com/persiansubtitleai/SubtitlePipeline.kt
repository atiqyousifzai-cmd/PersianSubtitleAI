package com.persiansubtitleai

import android.content.Context
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import java.io.File

/** Runs decoding -> chunked Whisper -> English/Persian translation -> SRT. Call off the UI thread. */
class SubtitlePipeline(context: Context) {
    private val appContext = context.applicationContext

    fun createPersianSubtitles(video: Uri, whisperModel: File, workDir: File): List<SubtitleSegment> {
        require(whisperModel.exists()) { "فایل مدل Whisper پیدا نشد" }
        workDir.mkdirs()
        val engine = WhisperEngine()
        val translatorReady = java.util.concurrent.CountDownLatch(1)
        var translatorInitError: Throwable? = null
        val translator = SubtitleTranslator { result ->
            translatorInitError = result.exceptionOrNull()
            translatorReady.countDown()
        }
        try {
            translator.prepare()
            check(translatorReady.await(5, java.util.concurrent.TimeUnit.MINUTES)) {
                "دانلود مدل ترجمه بیش از حد طول کشید"
            }
            translatorInitError?.let { throw it }
            check(engine.loadModel(whisperModel.absolutePath)) { "بارگذاری مدل Whisper ناموفق بود" }

            val translated = mutableListOf<SubtitleSegment>()
            AudioDecoder(appContext).decode16kChunks(video, 25) { samples, offsetMs ->
                if (samples.isNotEmpty()) {
                    engine.transcribeEnglish(samples, threads = 2).forEach { segment ->
                        val text = Tasks.await(translatorTask(translator, segment.text))
                        if (text.isNotBlank()) translated += SubtitleSegment(
                            startMs = segment.startMs + offsetMs,
                            endMs = segment.endMs + offsetMs,
                            text = text
                        )
                    }
                }
            }
            val srt = File(workDir, "persian_subtitles.srt")
            SrtWriter.write(translated, srt)
            return translated
        } finally {
            engine.release()
            translator.close()
        }
    }

    private fun translatorTask(translator: SubtitleTranslator, text: String): com.google.android.gms.tasks.Task<String> {
        val source = com.google.android.gms.tasks.TaskCompletionSource<String>()
        translator.translate(text) { result ->
            result.onSuccess { source.setResult(it) }.onFailure { source.setException(it) }
        }
        return source.task
    }
}
