package com.persiansubtitleai

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder

/** Decodes the selected video's audio to 16 kHz mono float PCM in bounded chunks. */
class AudioDecoder(private val context: Context) {
    fun decode16kChunks(uri: Uri, chunkSeconds: Int = 25, onChunk: (FloatArray, Long) -> Unit) {
        require(chunkSeconds in 10..30)
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            val track = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("این ویدیو صدای قابل‌خواندن ندارد")
            extractor.selectTrack(track)
            val inputFormat = extractor.getTrackFormat(track)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: error("فرمت صدا نامشخص است")
            val sourceRate = inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channels = inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            val chunk = FloatAccumulator(chunkSeconds * 16_000)
            var outputSamples = 0L
            var inputDone = false
            var outputDone = false
            val info = MediaCodec.BufferInfo()
            while (!outputDone) {
                if (!inputDone) {
                    val inIndex = codec.dequeueInputBuffer(10_000)
                    if (inIndex >= 0) {
                        val buffer = codec.getInputBuffer(inIndex)!!
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                when (val outIndex = codec.dequeueOutputBuffer(info, 10_000)) {
                    MediaCodec.INFO_TRY_AGAIN_LATER, MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> Unit
                    else -> if (outIndex >= 0) {
                        val buffer = codec.getOutputBuffer(outIndex)
                        if (buffer != null && info.size > 0) {
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            val pcm = buffer.slice().order(ByteOrder.LITTLE_ENDIAN)
                            val encoding = codec.outputFormat.getIntegerOrNull(MediaFormat.KEY_PCM_ENCODING) ?: 2
                            val bytesPerSample = if (encoding == 4) 4 else 2
                            val frames = info.size / (bytesPerSample * channels)
                            // Linear resampling to 16 kHz; average channels to mono.
                            val targetFrames = (frames.toLong() * 16_000L / sourceRate).toInt()
                            for (j in 0 until targetFrames) {
                                val srcFrame = minOf(frames - 1, (j.toLong() * sourceRate / 16_000L).toInt())
                                var mono = 0f
                                for (ch in 0 until channels) {
                                    val pos = (srcFrame * channels + ch) * bytesPerSample
                                    mono += if (encoding == 4) pcm.getFloat(pos) else pcm.getShort(pos).toFloat() / 32768f
                                }
                                chunk.add(mono / channels)
                                outputSamples++
                                if (chunk.size == chunkSeconds * 16_000) {
                                    onChunk(chunk.take(), (outputSamples - chunkSeconds * 16_000L) * 1000L / 16_000L)
                                }
                            }
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        codec.releaseOutputBuffer(outIndex, false)
                    }
                }
            }
            if (chunk.size > 0) onChunk(chunk.take(), (outputSamples - chunk.size) * 1000L / 16_000L)
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            extractor.release()
        }
    }

    private class FloatAccumulator(capacity: Int) {
        private val data = FloatArray(capacity)
        var size = 0; private set
        fun add(value: Float) { if (size < data.size) data[size++] = value }
        fun take(): FloatArray = data.copyOf(size).also { size = 0 }
    }

    private fun MediaFormat.getIntegerOrNull(key: String): Int? =
        try { if (containsKey(key)) getInteger(key) else null } catch (_: Exception) { null }
}
