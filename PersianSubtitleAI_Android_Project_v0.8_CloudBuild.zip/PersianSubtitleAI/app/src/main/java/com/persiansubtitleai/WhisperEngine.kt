package com.persiansubtitleai

/** JNI wrapper for whisper.cpp. Requires the native whisper library to be added and built. */
class WhisperEngine {
    companion object {
        init { System.loadLibrary("persian_whisper") }
    }

    private var context: Long = 0L

    @Synchronized
    fun loadModel(modelPath: String): Boolean {
        release()
        context = nativeInit(modelPath)
        return context != 0L
    }

    /** Audio must be mono, 16 kHz, normalized float PCM in [-1, 1]. */
    @Synchronized
    fun transcribeEnglish(samples: FloatArray, threads: Int = 2): List<SubtitleSegment> {
        check(context != 0L) { "Whisper model is not loaded" }
        check(samples.isNotEmpty()) { "Audio is empty" }
        val status = nativeTranscribe(context, samples, threads.coerceIn(1, 4))
        check(status == 0) { "Whisper transcription failed: $status" }
        return (0 until nativeSegmentCount(context)).map { index ->
            SubtitleSegment(
                startMs = nativeSegmentStartMs(context, index),
                endMs = nativeSegmentEndMs(context, index),
                text = nativeSegmentText(context, index).trim()
            )
        }.filter { it.text.isNotBlank() }
    }

    @Synchronized
    fun release() {
        if (context != 0L) nativeFree(context)
        context = 0L
    }

    private external fun nativeInit(modelPath: String): Long
    private external fun nativeTranscribe(context: Long, samples: FloatArray, threads: Int): Int
    private external fun nativeSegmentCount(context: Long): Int
    private external fun nativeSegmentStartMs(context: Long, index: Int): Long
    private external fun nativeSegmentEndMs(context: Long, index: Int): Long
    private external fun nativeSegmentText(context: Long, index: Int): String
    private external fun nativeFree(context: Long)
}
