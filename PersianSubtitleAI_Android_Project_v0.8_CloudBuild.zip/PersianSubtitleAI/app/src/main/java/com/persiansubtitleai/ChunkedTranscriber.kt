package com.persiansubtitleai

/** Splits 16 kHz mono PCM into short windows to reduce peak memory on 4 GB phones. */
class ChunkedTranscriber(
    private val engine: WhisperEngine,
    private val chunkSeconds: Int = 25,
    private val overlapSeconds: Int = 1,
    private val threads: Int = 2
) {
    fun transcribe(samples16kMono: FloatArray): List<SubtitleSegment> {
        require(chunkSeconds in 10..30)
        val sampleRate = 16_000
        val chunkSamples = chunkSeconds * sampleRate
        val overlapSamples = overlapSeconds.coerceIn(0, 3) * sampleRate
        val output = mutableListOf<SubtitleSegment>()
        var offset = 0
        while (offset < samples16kMono.size) {
            val end = minOf(offset + chunkSamples, samples16kMono.size)
            val window = samples16kMono.copyOfRange(offset, end)
            val offsetMs = offset * 1000L / sampleRate
            engine.transcribeEnglish(window, threads).forEach { segment ->
                val shifted = SubtitleSegment(
                    startMs = segment.startMs + offsetMs,
                    endMs = segment.endMs + offsetMs,
                    text = segment.text
                )
                // Discard duplicated text from the overlap area between adjacent chunks.
                if (output.isEmpty() || shifted.startMs >= output.last().endMs - 250L) {
                    output += shifted
                }
            }
            if (end == samples16kMono.size) break
            offset = end - overlapSamples
        }
        return output
    }
}
