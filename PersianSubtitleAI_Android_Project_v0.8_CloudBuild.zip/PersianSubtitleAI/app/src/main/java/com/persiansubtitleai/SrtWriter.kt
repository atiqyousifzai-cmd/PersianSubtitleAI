package com.persiansubtitleai

import java.io.File
import java.util.Locale

data class SubtitleSegment(
    val startMs: Long,
    val endMs: Long,
    val text: String
)

object SrtWriter {
    fun write(segments: List<SubtitleSegment>, output: File) {
        output.bufferedWriter(Charsets.UTF_8).use { writer ->
            segments.forEachIndexed { index, segment ->
                writer.append((index + 1).toString()).append('\n')
                writer.append(timestamp(segment.startMs))
                    .append(" --> ")
                    .append(timestamp(segment.endMs))
                    .append('\n')
                writer.append(segment.text.replace("-->", "—>")).append("\n\n")
            }
        }
    }

    private fun timestamp(ms: Long): String {
        val safe = ms.coerceAtLeast(0)
        val hours = safe / 3_600_000
        val minutes = (safe % 3_600_000) / 60_000
        val seconds = (safe % 60_000) / 1_000
        val millis = safe % 1_000
        return String.format(
            Locale.US, "%02d:%02d:%02d,%03d",
            hours, minutes, seconds, millis
        )
    }
}
