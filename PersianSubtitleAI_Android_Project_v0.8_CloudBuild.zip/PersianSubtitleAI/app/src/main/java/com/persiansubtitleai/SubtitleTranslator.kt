package com.persiansubtitleai

import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/**
 * English-to-Persian translation.
 * The Persian model is downloaded on first use and works offline afterward.
 */
class SubtitleTranslator(
    private val onReady: (Result<Unit>) -> Unit
) {
    private val translator: Translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.PERSIAN)
            .build()
    )

    fun prepare() {
        translator.downloadModelIfNeeded()
            .addOnSuccessListener { onReady(Result.success(Unit)) }
            .addOnFailureListener { onReady(Result.failure(it)) }
    }

    fun translate(text: String, onResult: (Result<String>) -> Unit) {
        translator.translate(text)
            .addOnSuccessListener { onResult(Result.success(it)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun close() {
        translator.close()
    }
}
