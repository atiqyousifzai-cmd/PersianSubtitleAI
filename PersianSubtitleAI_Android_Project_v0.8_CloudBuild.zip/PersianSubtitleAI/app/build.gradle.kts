plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.persiansubtitleai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.persiansubtitleai"
        minSdk = 23
        targetSdk = 35
        versionCode = 7
        versionName = "0.7.0"

        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
        externalNativeBuild { cmake { cppFlags += "-std=c++17"; arguments += "-DANDROID_STL=c++_shared" } }
    }

    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
}

dependencies {
    // On-device English -> Persian translation. Model is downloaded on first use.
    implementation("com.google.mlkit:translate:17.0.3")

    // Android video processing/export foundation for the next stage.
    implementation("androidx.media3:media3-transformer:1.5.1")
    implementation("androidx.media3:media3-effect:1.5.1")
    implementation("androidx.media3:media3-common:1.5.1")
}
