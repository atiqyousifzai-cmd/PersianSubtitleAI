@echo off
setlocal
set ROOT=%~dp0..
set OUT=%ROOT%\app\src\main\assets\models
if not exist "%OUT%" mkdir "%OUT%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.en.bin' -OutFile '%OUT%\ggml-tiny.en.bin'"
if errorlevel 1 exit /b 1
echo Model downloaded to %OUT%
