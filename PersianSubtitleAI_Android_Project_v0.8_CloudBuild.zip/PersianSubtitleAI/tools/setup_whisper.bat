@echo off
setlocal
set ROOT=%~dp0..
set CPP=%ROOT%\app\src\main\cpp
set DEST=%CPP%\whisper
where git >nul 2>nul || (echo Git is required. Install Git first.& exit /b 1)
if exist "%DEST%\.git" (
  git -C "%DEST%" pull --ff-only || exit /b 1
) else (
  if exist "%DEST%" rmdir /s /q "%DEST%"
  git clone --depth 1 https://github.com/ggml-org/whisper.cpp.git "%DEST%" || exit /b 1
)
if not exist "%DEST%\include\whisper.h" (echo whisper.cpp checkout is incomplete.& exit /b 1)
echo whisper.cpp source installed. Now open the project in Android Studio.
