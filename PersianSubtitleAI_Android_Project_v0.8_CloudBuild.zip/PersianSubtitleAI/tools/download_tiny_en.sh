#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/app/src/main/assets/models"
mkdir -p "$OUT"
URL='https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.en.bin'
if command -v curl >/dev/null 2>&1; then curl -L --fail --retry 3 "$URL" -o "$OUT/ggml-tiny.en.bin"
elif command -v wget >/dev/null 2>&1; then wget -O "$OUT/ggml-tiny.en.bin" "$URL"
else echo 'Install curl or wget.' >&2; exit 1; fi
ls -lh "$OUT/ggml-tiny.en.bin"
