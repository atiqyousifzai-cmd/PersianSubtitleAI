#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CPP="$ROOT/app/src/main/cpp"
DEST="$CPP/whisper"
if ! command -v git >/dev/null 2>&1; then echo 'Git is required. Install Git first.' >&2; exit 1; fi
if [ -d "$DEST/.git" ]; then
  git -C "$DEST" pull --ff-only
else
  rm -rf "$DEST"
  git clone --depth 1 https://github.com/ggml-org/whisper.cpp.git "$DEST"
fi
if [ ! -f "$DEST/include/whisper.h" ]; then echo 'whisper.cpp checkout is incomplete.' >&2; exit 1; fi
echo "whisper.cpp source installed at: $DEST"
echo 'Next: open the project in Android Studio, install Android NDK and CMake 3.22.1, then Build > Build Bundle(s) / APK(s) > Build APK(s).'
